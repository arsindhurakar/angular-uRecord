import { Component, OnInit } from '@angular/core';
import { MdbModalRef } from 'mdb-angular-ui-kit/modal';

import { UsersRecordService } from 'src/app/services/users-record.service';
import { IUserRecord } from 'src/app/interfaces/user-record';

@Component({
  selector: 'app-remove-record',
  templateUrl: './remove-record.component.html',
  styleUrls: ['./remove-record.component.scss'],
})
export class RemoveRecordComponent implements OnInit {
  public record: IUserRecord;

  constructor(
    private usersRecordService: UsersRecordService,
    public modalRef: MdbModalRef<RemoveRecordComponent>
  ) {}

  ngOnInit(): void {}

  onRemove() {
    this.usersRecordService.removeUserRecord(this.record._id).subscribe(
      (res) => {
        if (res.success === true) {
          this.modalRef.close(this.record._id);
        } else {
          this.modalRef.close();
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }
}
