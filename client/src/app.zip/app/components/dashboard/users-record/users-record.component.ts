import { Component, OnInit } from '@angular/core';
import { MdbModalRef, MdbModalService } from 'mdb-angular-ui-kit/modal';

import { UsersRecordService } from 'src/app/services/users-record.service';
import { IUserRecord } from '../../../interfaces/user-record';
import { EditRecordComponent } from './edit-record/edit-record.component';
import { RemoveRecordComponent } from './remove-record/remove-record.component';
import { AddRecordComponent } from './add-record/add-record.component';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-users-record',
  templateUrl: './users-record.component.html',
  styleUrls: ['./users-record.component.scss'],
})
export class UsersRecordComponent implements OnInit {
  public records: object[];

  public headElements: string[] = [
    '#',
    'Name',
    'Email',
    'Street',
    'City',
    'Contact No',
    'Subscription',
    'Actions',
  ];

  public keyElements: string[] = [
    'name',
    'email',
    'street',
    'city',
    'contactNo',
  ];

  newModalRef: MdbModalRef<EditRecordComponent>;
  editModalRef: MdbModalRef<EditRecordComponent>;
  removeModalRef: MdbModalRef<RemoveRecordComponent>;

  constructor(
    private usersRecordService: UsersRecordService,
    private modalService: MdbModalService,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.getUsersRecord();
  }

  getUsersRecord(): void {
    this.usersRecordService.getUsersRecord().subscribe(
      (res) => {
        this.records = res['records'];
      },
      (err) => {
        console.log(err);
      }
    );
  }

  onNewRecord(): void {
    this.newModalRef = this.modalService.open(AddRecordComponent, {
      ignoreBackdropClick: true,
    });
    this.newModalRef.onClose.subscribe((record: IUserRecord) => {
      if (record) {
        this.records.unshift(record);
        this.toastr.success('Added to records.');
      }
    });
  }

  onRemove(record: IUserRecord): void {
    this.removeModalRef = this.modalService.open(RemoveRecordComponent, {
      data: { record: record },
      ignoreBackdropClick: true, // prevent closing modal from backdrop click
    });
    this.removeModalRef.onClose.subscribe((id: string) => {
      if (!id) {
        this.toastr.error('Nothing was removed');
      } else {
        let index = this.records.findIndex(
          (rec: IUserRecord) => rec._id === id
        );
        this.records.splice(index, 1);
        this.toastr.success('Removed successfully');
      }
    });
  }

  onEdit(record: IUserRecord): void {
    this.editModalRef = this.modalService.open(EditRecordComponent, {
      data: { record: record },
      ignoreBackdropClick: true, // prevent closing modal from backdrop click
    });
    this.editModalRef.onClose.subscribe((record: IUserRecord) => {
      if (record) {
        const { _id, name, email, address, contactNo, isSubscribed } = record;
        let index = this.records.findIndex(
          (rec: IUserRecord) => rec._id === _id
        );
        this.records[index] = {
          _id,
          name,
          email,
          address,
          contactNo,
          isSubscribed,
        };
        this.toastr.success('Updated successfully');
      } else {
        this.toastr.error('Nothing was updated');
      }
    });
  }
}
