import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { MdbModalRef } from 'mdb-angular-ui-kit/modal';

import { SharedFormService } from 'src/app/services/shared-form.service';
import { UsersRecordService } from 'src/app/services/users-record.service';

@Component({
  selector: 'app-add-record',
  templateUrl: './add-record.component.html',
  styleUrls: ['./add-record.component.scss'],
})
export class AddRecordComponent implements OnInit {
  public formAddRecord: FormGroup = null;

  public isProcessing: boolean = false;

  public emailRegex: RegExp =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  get sharedGroup() {
    return this.formAddRecord.get('sharedGroup');
  }

  constructor(
    private formBuilder: FormBuilder,
    private sharedFormService: SharedFormService,
    private usersRecordService: UsersRecordService,
    private toastr: ToastrService,
    public modalRef: MdbModalRef<AddRecordComponent>
  ) {}

  ngOnInit(): void {
    this.formAddRecord = this.formBuilder.group({
      sharedGroup: this.sharedFormService.sharedForm(),
    });

    // console.log(this.sharedForm);
    // //conditional validation
    // this.sharedForm.get('isSubscribed').valueChanges.subscribe((isChecked) => {
    //   const email = this.sharedForm.get('email');
    //   if (isChecked) {
    //     email.setValidators([
    //       Validators.required,
    //       Validators.pattern(this.emailRegex),
    //     ]);
    //   } else {
    //     email.clearValidators();
    //   }
    //   email.updateValueAndValidity();
    // });
  }

  onAddRecord() {
    this.isProcessing = true;
    if (!this.formAddRecord.invalid) {
      this.usersRecordService.addUserRecord(this.sharedGroup.value).subscribe(
        (res) => {
          console.log('res', res);
          this.modalRef.close(res);
        },
        (err) => {
          if (err.status === 422) {
            this.toastr.error(err.error[0]);
            this.isProcessing = false;
          }
        }
      );
    } else {
      this.isProcessing = false;
      this.toastr.error('Invalid details');
    }
  }
}
