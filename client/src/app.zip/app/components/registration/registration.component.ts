import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { passwordValidator } from '../../utils/password.validator';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss'],
})
export class RegistrationComponent implements OnInit {
  public registrationForm: FormGroup;
  public serverErrorMessage: string;
  public isSuccess: boolean;
  public isProcessing: boolean = false;

  get fullName() {
    return this.registrationForm.get('fullName');
  }

  get email() {
    return this.registrationForm.get('email');
  }

  get password() {
    return this.registrationForm.get('password');
  }

  get confirmPassword() {
    return this.registrationForm.get('confirmPassword');
  }

  public emailRegex: RegExp =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.registrationForm = this.formBuilder.group(
      {
        fullName: [null, Validators.required],
        email: [
          null,
          [Validators.required, Validators.pattern(this.emailRegex)],
        ],
        password: [null, [Validators.required, Validators.minLength(6)]],
        confirmPassword: [null, Validators.required],
      },
      { validator: passwordValidator }
    );
  }

  handleRegistration(): void {
    // console.log(this.registrationForm.value);
    this.serverErrorMessage = null;
    this.isProcessing = true;

    if (this.registrationForm.invalid) {
      this.serverErrorMessage = 'Invalid details';
      this.isProcessing = false;
    } else {
      this.userService.register(this.registrationForm.value).subscribe(
        (res) => {
          this.isSuccess = true;
          setTimeout(() => (this.isSuccess = false), 3000);
          this.isProcessing = false;
        },
        (err) => {
          if (err.status === 422) {
            this.serverErrorMessage = err.error.join('<br />');
            console.log(err.error);
          }
          this.isProcessing = false;
        }
      );
    }
  }
}
