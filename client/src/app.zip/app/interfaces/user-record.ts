interface IAddressData {
  street: string;
  city: string;
}

export interface IUserRecord {
  _id: string;
  name: string;
  contactNo: string;
  // alternateContactNos: [];
  address: IAddressData;
  email: string;
  isSubscribed: boolean;
  success: boolean;
}
