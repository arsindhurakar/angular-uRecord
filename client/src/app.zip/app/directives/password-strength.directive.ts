import { Directive } from '@angular/core';

@Directive({
  selector: '[appPasswordStrength]',
})
export class PasswordStrengthDirective {
  constructor() {}
}
