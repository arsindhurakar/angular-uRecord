import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { environment } from '../../environments/environment';
import { IUserRecord } from '../interfaces/user-record';

@Injectable({
  providedIn: 'root',
})
export class UsersRecordService {
  noAuthHeader = { headers: new HttpHeaders({ NoAuth: 'True' }) }; // applied to those that doesnt need jwt

  constructor(private http: HttpClient) {}

  addUserRecord(userRecord: IUserRecord): Observable<IUserRecord> {
    return this.http
      .post<IUserRecord>(
        environment.apiBaseUrl + '/add-record',
        userRecord,
        this.noAuthHeader
      )
      .pipe(catchError(this.errorHandler));
  }

  getUsersRecord(): Observable<IUserRecord> {
    return this.http
      .get<IUserRecord>(
        environment.apiBaseUrl + '/get-records',
        this.noAuthHeader
      )
      .pipe(catchError(this.errorHandler));
  }

  removeUserRecord(id: string): Observable<IUserRecord> {
    return this.http
      .delete<IUserRecord>(
        environment.apiBaseUrl + '/remove-record/' + id, //id sent as params
        this.noAuthHeader
      )
      .pipe(catchError(this.errorHandler));
  }

  updateUserRecord(updates: IUserRecord): Observable<IUserRecord> {
    return this.http
      .put<IUserRecord>(
        environment.apiBaseUrl + '/update-record',
        updates,
        this.noAuthHeader
      )
      .pipe(catchError(this.errorHandler));
  }

  errorHandler(error: HttpErrorResponse) {
    return throwError(error);
  }
}
